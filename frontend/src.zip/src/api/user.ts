import { request } from '@/utils/request'


export function panel(params?: any) {
  return request({url: '/user/panel', method: 'get', params })
}


export function historyOther(params?: any) {
  return request({url:'/user/my_history_other',method: 'get', params })
}

export function friends(params?: any) {
  return request({url:'/user/friends',method: 'get', params })
}

export function userinfo(params?: any) {
  return request({url:'/user/userinfo',method: 'get', params })
}



