import { request } from '@/utils/request'


export function myVideo(params?: any) {
  return request({ url: '/user/my_video', method: 'get', params });
}

export function privateVideo(params?: any) {
  return request({ url: '/user/my_private', method: 'get', params });
}

export function likeVideo(params?: any) {
  return request({ url: '/user/my_like_video', method: 'get', params });
}

export function collectVideo(params?: any) {
  return request({ url: '/user/my_collect_video', method: 'get', params });
}

export function recommendedVideo(params?: any) {
  return request({ url: '/video/recommended', method: 'get', params });
}

export function recommendedLongVideo(params?: any) {
  return request({ url: '/video/long_recommended', method: 'get', params });
}

export function historyVideo(params?: any) {
  return request({ url: '/user/my_history_video', method: 'get', params });
}

export function videoComments(params?: any) {
  return request({ url: '/video/comments', method: 'get', params });
}

export function videoComment(params?: any, data?: any) {
  return request({ url: '/video/comment', method: 'post', params, data });
}

export function userVideoList(params?: any) {
  return request({ url: '/user/video_list', method: 'get', params });
}

export function videoDigg(params?: any, data?: any) {
  return request({ url: '/video/digg', method: 'post', params, data });
}

export function videoCollect(params?: any, data?: any) {
  return request({ url: '/video/collect', method: 'post', params, data });
}

export function videoShare(params?: any) {
  return request({ url: '/video/share', method: 'post', params });
}

export function videoDiggStatus(params?: any, data?: any) {
  return request({ url: '/video/digg_status', method: 'get', params, data });
}

export function videoCollectStatus(params?: any, data?: any) {
  return request({ url: '/video/collect_status', method: 'get', params, data });
}
